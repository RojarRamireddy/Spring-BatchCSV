DROP TABLE duptinee IF EXISTS;
CREATE TABLE duptinee  (
    tin VARCHAR(10),
    ecn1 VARCHAR(10),
    name1 VARCHAR(50),
    dob1 VARCHAR(50),
    ecn2 VARCHAR(10),
    name2 VARCHAR(50),
    dob2 VARCHAR(50),
    ecn3 VARCHAR(10),
    name3 VARCHAR(50),
    dob3 VARCHAR(50)
);
