package com.wellsfargo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.batch.item.ItemProcessor;

public class DupTinEEProcessor implements ItemProcessor<DupTinEEDTO, DupTinEEDTO> {
	
    private static final Logger log = LoggerFactory.getLogger(DupTinEEProcessor.class);
    
    @Override
    public DupTinEEDTO process(final DupTinEEDTO DupTinEEDTO) throws Exception {
    	
    	final String tin = DupTinEEDTO.getTin();
    	final String ecn1 = DupTinEEDTO.getEcn1();
    	final String name1 = DupTinEEDTO.getName1();
    	final String dob1 = DupTinEEDTO.getDob1();
    	final String ecn2 = DupTinEEDTO.getEcn2();
    	final String name2 = DupTinEEDTO.getName2();
    	final String dob2 = DupTinEEDTO.getDob2();
    	final String ecn3 = DupTinEEDTO.getEcn3();
    	final String name3 = DupTinEEDTO.getName3();
    	final String dob3 = DupTinEEDTO.getDob3();
    	
        final DupTinEEDTO transformedDupTinEEDTO = new DupTinEEDTO(tin, ecn1, name1, dob1, ecn2, name2, dob2, ecn3, name3, dob3);

        log.info("Converting (" + DupTinEEDTO + ") into (" + transformedDupTinEEDTO + ")");

        return transformedDupTinEEDTO;
    }

}
