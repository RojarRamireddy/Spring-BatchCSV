package com.wellsfargo;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

@EnableBatchProcessing
@Configuration
public class CsvFileToDatabaseConfig {
	
    @Autowired
    public JobBuilderFactory jobBuilderFactory;

    @Autowired
    public StepBuilderFactory stepBuilderFactory;

    @Autowired
    public DataSource dataSource;
    
    // begin reader, writer, and processor

    //@Value("${Duptinee.csv}")
    //private String filePath;
    @Bean
    public FlatFileItemReader<DupTinEEDTO> csvDupTinEEReader(){
        FlatFileItemReader<DupTinEEDTO> reader = new FlatFileItemReader<DupTinEEDTO>();
        reader.setResource(new ClassPathResource("Duptinee.csv"));
        reader.setLineMapper(new DefaultLineMapper<DupTinEEDTO>() {{
            setLineTokenizer(new DelimitedLineTokenizer() {{
                setNames(new String[] { "TIN", "ECN1", "NAME1", "DOB1", "ECN2", "NAME2", "DOB2", "ECN3", "NAME3", "DOB3" });
            }});
            setFieldSetMapper(new BeanWrapperFieldSetMapper<DupTinEEDTO>() {{
                setTargetType(DupTinEEDTO.class);
            }});
        }});
        return reader;
    }


	@Bean
	ItemProcessor<DupTinEEDTO, DupTinEEDTO> csvDupTinEEProcessor() {
		return new DupTinEEProcessor();
	}

	@Bean
	public JdbcBatchItemWriter<DupTinEEDTO> csvAnimeWriter() {
		 JdbcBatchItemWriter<DupTinEEDTO> csvAnimeWriter = new JdbcBatchItemWriter<DupTinEEDTO>();
		 csvAnimeWriter.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<DupTinEEDTO>());
		 csvAnimeWriter.setSql("INSERT INTO DUPTINEE (tin, ecn1, name1, dob1, ecn2, name2, dob2, ecn3, name3, dob3) "
		 		+ "VALUES (:tin, :ecn1, :name1, :dob1, :ecn2, :name2, :dob2, :ecn3, :name3, :dob3)");
		 csvAnimeWriter.setDataSource(dataSource);
	        return csvAnimeWriter;
	}

	 // end reader, writer, and processor

    // begin job info
	@Bean
	public Step csvFileToDatabaseStep() {
		return stepBuilderFactory.get("csvFileToDatabaseStep")
				.<DupTinEEDTO, DupTinEEDTO>chunk(1)
				.reader(csvDupTinEEReader())
				.processor(csvDupTinEEProcessor())
				.writer(csvAnimeWriter())
				.build();
	}

	@Bean
	Job csvFileToDatabaseJob(JobCompletionNotificationListener listener) {
		return jobBuilderFactory.get("csvFileToDatabaseJob")
				.incrementer(new RunIdIncrementer())
				.listener(listener)
				.flow(csvFileToDatabaseStep())
				.end()
				.build();
	}
	 // end job info
}
