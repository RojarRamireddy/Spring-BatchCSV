package com.wellsfargo;

import org.apache.commons.lang3.builder.ToStringBuilder;
/**
 * Contains the information of a single anime
 *
 * @author Michael C Good michaelcgood.com
 */

public class DupTinEEDTO {
	
	public String getTin() {
		return tin;
	}

	private String tin;
	
	public String getEcn1() {
		return ecn1;
	}

	public void setEcn1(String ecn1) {
		this.ecn1 = ecn1;
	}

	public String getName1() {
		return name1;
	}

	public void setName1(String name1) {
		this.name1 = name1;
	}

	public String getDob1() {
		return dob1;
	}

	public void setDob1(String dob1) {
		this.dob1 = dob1;
	}

	public String getEcn2() {
		return ecn2;
	}

	public void setEcn2(String ecn2) {
		this.ecn2 = ecn2;
	}

	public String getName2() {
		return name2;
	}

	public void setName2(String name2) {
		this.name2 = name2;
	}

	public String getDob2() {
		return dob2;
	}

	public void setDob2(String dob2) {
		this.dob2 = dob2;
	}

	public String getEcn3() {
		return ecn3;
	}

	public void setEcn3(String ecn3) {
		this.ecn3 = ecn3;
	}

	public String getName3() {
		return name3;
	}

	public void setName3(String name3) {
		this.name3 = name3;
	}

	public String getDob3() {
		return dob3;
	}

	public void setDob3(String dob3) {
		this.dob3 = dob3;
	}

	public void setTin(String tin) {
		this.tin = tin;
	}



	private String ecn1;
	private String name1;
	private String dob1;
	private String ecn2;
	private String name2;
	private String dob2;
	private String ecn3;
	private String name3;	
	private String dob3;
	
	public DupTinEEDTO(){
		
	}
	
	public DupTinEEDTO(String tin, String ecn1, String name1, String dob1,
								   String ecn2, String name2, String dob2,
								   String ecn3, String name3, String dob3){
		this.tin = tin;
		this.ecn1 = ecn1;
		this.name1 = name1;
		this.dob1 = dob1;
		this.ecn2 = ecn2;
		this.name2 = name2;
		this.dob2 = dob2;
		this.ecn3  = ecn3;
		this.name3 = name3;
		this.dob3 = dob3;
		
	}
	

	
	   @Override
	    public String toString() {
		   return new ToStringBuilder(this)
				   .append("tin", this.tin)
				   .append("ecn1", this.ecn1)
				   .append("name1", this.name1)
				   .append("dob1", this.dob1)
				   .append("ecn2", this.ecn2)
				   .append("name2", this.name2)
				   .append("dob2", this.dob2)
				   .append("ecn3", this.ecn3)
				   .append("name3", this.name3)
				   .append("dob3", this.dob3)
				   .toString();
	   }


}
