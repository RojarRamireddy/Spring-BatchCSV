# SpringBatchCSV
Reading a CSV file using FlatFileItemReader in Spring Batch Application
